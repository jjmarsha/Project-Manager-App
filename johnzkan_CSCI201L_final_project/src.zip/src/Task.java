
public class Task {
	public String name="";
	public String date="";
	public String description="";
	public String projID;
	public String taskID;
	public String status;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String descript) {
		this.description = descript;
	}
	public String getProjID() {
		return projID;
	}
	public void setProjID(String projID) {
		this.projID = projID;
	}
	
	public String getTaskID() {
		return taskID;
	}
	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
