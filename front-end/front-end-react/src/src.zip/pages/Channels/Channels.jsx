import React from 'react';
import Page from "../../components/Page";


export default class Channels extends React.Component {
    render() {
        return(
            <Page>
                Channels
            </Page>
        )
    }
}